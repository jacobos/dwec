(function() {

  $(document.body).on("click", function() {


  });
})();
/*
var myShop = {
  "albornoces": {
    "albornoces feos": [
      {
        "del patito feo": {
          "precio": 77,
          "src": "img/patito.png",
          "desc": "..."
        }
      }
    ],
    "albornoces bonitos": [

    ]
  }
};
//$.each(myShop, function(..){...})

<div class="col-md-3 col-sm-6">
  <div class="thumbnail">
    <img src="http://lorempixel.com/800/500/sports/2" alt="Placeholder">
    <div class="caption">
      <h3>Sea</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      <p>
        <a href="#" class="btn btn-primary">Buy Now!</a> <a href="#" class="btn btn-default">More Info</a>
      </p>
    </div>
  </div>
</div>*/
