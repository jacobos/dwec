/*global document */

(function () {
    'use strict';
    var myImg,
        button1,
        button2,
        num_images,
        myArray = ["009.png", "010.png", "011.png"];
    /*button1 = ... get the button1 element*/
    /*button2 = ... get the button2 element*/
    num_images = myArray.length;
    button1.onclick = function () {
        // create the event
    };
    button2.onclick = function () {
        // create the event
    };
}());