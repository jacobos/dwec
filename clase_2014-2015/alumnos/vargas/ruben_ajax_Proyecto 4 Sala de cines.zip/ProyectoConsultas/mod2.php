<?php

include("conexion.php"); 

        $codigo = $_POST['codigo'];
		$titulo = $_POST['titulo'];
		$descripcion = $_POST['descripcion'];
		$duracion = $_POST['duracion'];
		$precio = $_POST['precio'];
        
        

            mysqli_query($conexion," UPDATE `Peliculas` SET `cod_peliculas`='$codigo',`nom_peliculas`='$titulo',`descripcion`='$descripcion',`duracion`='$duracion',`precio`='$precio' WHERE `cod_peliculas`='$codigo'");
    //$consulta = mysqli_query($conexion,$sql);
     
    

                   
/*                           echo'<select class="form-control modifi2">
                               <option> </option>';
                                $sql = "SELECT  * from Peliculas";
                                $consulta = mysqli_query($conexion,$sql);
                                while($horas = mysqli_fetch_array($consulta)){
                                    
                                   echo utf8_encode( '<option>'.$horas[0].'</option>');
                                }
                                
                            echo'</select>
                        </div>';*/

mysqli_close();
?>