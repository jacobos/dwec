<?php

$conexion = mysqli_connect("localhost","php","123456","ProyectoConsultas");
/*if(mysqli_connect_errno()){
		echo "No se pudo conectar a la base de datos: ". mysqli_connect_error();
	}else{
		echo "La conexion se ha realizado correctamente";
	}*/
	

?>