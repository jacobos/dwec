<!DOCTYPE html>
<html lang="es">
<?php session_start(); ?>
<?php include('conexion.php')?>
<head>
    <meta charset="UTF-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/font-awesome.min.css" rel="stylesheet">
        <script src="../css/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
        <style>body{background-color:#1560BD;}</style>
    <title>Document</title>
</head>
<body>
<?php include('menu.php')?>
 
 El Septimo Hijo

</body>
</html>