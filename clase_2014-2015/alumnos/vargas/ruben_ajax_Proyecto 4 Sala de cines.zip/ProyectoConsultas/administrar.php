<!DOCTYPE html>
<html lang="es">
<?php /*session_start(); if ($_SESSION[ 'sesion']=="" ){ header( 'location:acceso.php'); }*/ ?>
<?php include( 'conexion.php')?>

<head>
    <meta charset="UTF-8">
    
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="css/bootstrap.min.js"></script>

    <style>
        body {
            background-color: #1560BD;
        }
        -webkit-input-placeholder { color: green; } 
    </style>
    <title>Document</title>

</head>

<body>
    <?php include( 'menu.php')?>

    <div class="panel panel-default" style="width:80½; margin:0 auto;">
        <div class="panel-body" id="addd" style="background:#8B8378; color:white;">
            Añadir Peliculas
        </div>
        <div class="panel-body" id="addd2" style="background:#E3E3E3;">
            <form class="form-horizontal">
               <h3><span class="label label-default">Info Peliculas</span></h3>
                <div class="form-group col-lg-1">
                    <input type="text" class="form-control" placeholder="Codigo" id="codigo" required>
                </div>
                <div class="form-group col-lg-4">
                    <input type="text" class="form-control" placeholder="Titulo" id="titulo" required>
                </div>
                <div class="form-group col-lg-2">
                    <input type="text" class="form-control" placeholder="Duracion" id="duracion" required>
                </div>
                <div class="form-group col-lg-1">
                    <input type="text" class="form-control" placeholder="Precio" id="precio" required>
                </div>
                <br>
                <div class="form-group col-lg-12 ">
                    <textarea class="form-control" rows="5" placeholder="Descripcion" id="descripcion" required></textarea>
                </div>
                <br>
                <br>
                <br>
                <h3><span class="label label-default">Info Sesiones</span></h3>
                <div class="form-group col-lg-2">
                    <input type="text" class="form-control" placeholder="Sesion" id="sesion" required>
                </div>
                <div class="form-group col-lg-1">                        
                <label class="col-lg-1 control-label">Sala</label>
                </div>
                <div class="form-group col-lg-1">
                           <select class="form-control select">
                                <?php
                                $sql = "SELECT  * from Salas";
                                $consulta = mysqli_query($conexion,$sql);
                                while($salas = mysqli_fetch_array($consulta)){ 
                                   echo utf8_encode( '<option>'.$salas[0].'</option>');
                                }
                                ?>
                            </select>
                </div>
                <div class="form-group col-lg-1">                        
                <label class="col-lg-1 control-label">Hora</label>
                </div>
                <div class="form-group col-lg-2">
                           <select class="form-control horas">
                                <?php
                                $sql = "SELECT  * from Horas";
                                $consulta = mysqli_query($conexion,$sql);
                                while($horas = mysqli_fetch_array($consulta)){ 
                                   echo utf8_encode( '<option>'.$horas[0].'</option>');
                                }
                                ?>
                            </select>
                </div>
                <div class="form-group col-lg-1">                        
                <label class="col-lg-1 control-label">Fecha</label>
                </div>
                <div class="form-group col-lg-2">
                    <input type="date" class="form-control" placeholder="dia" id="dia">
                </div>

 
<!--                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Portada">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Url">
                </div>-->
                <hr>
                <center><button type="button" class="btn btn-success" id="add" >Añadir</button></center>
            </form>
        </div>
    <div class="panel-body" id="modificar" style="background:#8B8378; color:white;">
            Modificar Peliculas
    </div>
    <div class="panel-body" id="modificar2" style="background:#E3E3E3;">
         <form class="form-horizontal">
                <div class="form-group col-lg-2">                        
                <label class="col-lg-2 control-label">Codigo_Peliculas</label>
                </div>
                <div class="form-group col-lg-1 modifi2">
                           <select class="form-control modifi" id="modifi">
                               <option> </option>
                                <?php
                                $sql = "SELECT  * from Peliculas";
                                $consulta = mysqli_query($conexion,$sql);
                                while($horas = mysqli_fetch_array($consulta)){
                                    
                                   echo utf8_encode( '<option>'.$horas[0].'</option>');
                                }
                                ?>
                            </select>
                </div>
                <div class="form-group col-lg-12" id="modborrar">
                
                </div>
                <br>
                <br>
                <div class="form-group col-lg-4">
                    <input type="text" class="form-control" placeholder="Titulo" id="titulom" required>
                </div>
                <div class="form-group col-lg-2">
                    <input type="text" class="form-control" placeholder="Duracion" id="duracionm" required>
                </div>
                <div class="form-group col-lg-1">
                    <input type="text" class="form-control" placeholder="Precio" id="preciom" required>
                </div>
                <br>
                <div class="form-group col-lg-12 ">
                    <textarea class="form-control" rows="5" placeholder="Descripcion" id="descripcionm" required></textarea>
                 </div>
            </form>
               <br>
               <center><button type="submit" class="btn btn-warning" id="mod">Modificar</button></center>

    </div>
        
        <div class="panel-body" id="eliminar" style="background:#8B8378; color:white;">
            Eliminar Peliculas
        </div>
        <div class="panel-body" id="eliminar2" style="background:#E3E3E3;">
          <div class="borrardiv"><?php
        $sql = "SELECT  * from Peliculas";
        $consulta = mysqli_query($conexion,$sql);
        while($pelis = mysqli_fetch_array($consulta)){ 
            echo utf8_encode( '<H3><span class="label label-primary">'.$pelis[0].' '.$pelis[1].'</span></h3>');
            //echo utf8_encode( '<span class="label label-primary">'.$pelis[1].'</span></H3><br>');
        }
        ?>
        <hr>
        <center>
        <select class="form-control paraeliminar">
        <?php
        $sql = "SELECT  * from Peliculas";
        $consulta = mysqli_query($conexion,$sql);
        while($pelis = mysqli_fetch_array($consulta)){ 
           echo utf8_encode( '<option>'.$pelis[0].'</option>');
        }
        ?>
        </select>
         </center>
        </div>
        <hr>
        <center>
             <button type="submit" class="btn btn-danger" id="del">Eliminar</button>
        </center>
    </div>

    <script>
                $(".modifi").on("click", function () {
        
                    $.ajax({
                 type: "POST",
                        url: "mod.php",
                        data: {
                            modifi: $('.modifi').val()
                            },
                        success: function (responses) {

                        $('#modborrar').empty();
                        $('#modborrar').append(responses);                        
                        },
                                });
                    });
$("#mod").on("click", function () {
        
                    $.ajax({
                 type: "POST",
                        url: "mod2.php",
                        data: {                        
                        codigo: $('.modifi').val(),
                        titulo: $('#titulom').val(),
                        descripcion: $('#descripcionm').val(),
                        duracion: $('#duracionm').val(),
                        precio: $('#preciom').val()
                            },
                        success: function (responses) {
                        alert('Pelicula modificada correctamente');
                        window.location = "http://www.rubenfreelance.tk/Proyectos/ProyectoConsultas/administrar.php";

                        },
                                }); 
            
                       $.ajax({
                 type: "POST",
                        url: "del.php",
                        data: {
                        
                            },
                        success: function (responses) {

                        $('.borrardiv').empty();
                        $('.borrardiv').append(responses);
                        },
                                }); 
                    $.ajax({
                 type: "POST",
                        url: "add.php",
                        data: {
                        
                            },
                        success: function (responses) {

                        $('.tableru').empty();
                        $('.tableru').append(responses);
                        },
                                });
        
            
        });
        var contador1 = 0;
        $('#addd2').hide();

        $('#addd').on("click", function () {
            if (contador1 == 0) {
                $('#addd').next().show();
                contador1 = 1;
            } else {
                $('#addd').next().hide();
                contador1 = 0;
            }

        });
        
        
        var contador2 = 0;
        $('#eliminar2').hide();

        $('#eliminar').on("click", function () {
            if (contador2 == 0) {
                $('#eliminar').next().show();
                contador2 = 1;
            } else {
                $('#eliminar').next().hide();
                contador2 = 0;
            }

        });
        
        var contador2 = 3;
        $('#modificar2').hide();

        $('#modificar').on("click", function () {
            if (contador2 == 0) {
                $('#modificar').next().show();
                contador2 = 1;
            } else {
                $('#modificar').next().hide();
                contador2 = 0;
            }

        });
        
        $("#add").on("click", function () { //add mod del
            $.ajax({
                 type: "POST",
             url: "add.php",
                        data: {
                        codigo: $('#codigo').val(),
                        titulo: $('#titulo').val(),
                        descripcion: $('#descripcion').val(),
                        duracion: $('#duracion').val(),
                        precio: $('#precio').val(),
                        sesion: $('#sesion').val(),
                        sala: $('.select').val(),
                        horas: $('.horas').val()
                            },
                        success: function (response) {
                        alert('Pelicula añadida correctamente');
                        $('.tableru').empty();
                        $('.tableru').append(response);
  
                                }
                            
                                });
                  
            $.ajax({
                 type: "POST",
                        url: "del.php",
                        data: {
                        
                            },
                        success: function (responses) {

                        $('.borrardiv').empty();
                        $('.borrardiv').append(responses);
                        },
                                });
            $.ajax({
                 type: "POST",
                        url: "mod2.php",
                        data: {
                        
                            },
                        success: function (responses) {

        
                        },
                                });          

                        });
        
        
        $("#del").on("click", function () { //add mod del
            $.ajax({
                 type: "POST",
                        url: "del.php",
                        data: {
                        codigo: $('.paraeliminar').val()
                        
                            },
                        success: function (response) {
                            alert('Pelicula eliminada correctamente');
                            $('.borrardiv').empty();
                            $('.borrardiv').append(response);
                            
                                },
                                });
            
            $.ajax({
                 type: "POST",
                        url: "add.php",
                        data: {
                        
                            },
                        success: function (responses) {

                        $('.tableru').empty();
                        $('.tableru').append(responses);
                        },
                                });
            
                        $.ajax({
                 type: "POST",
                        url: "mod2.php",
                        data: {
                        
                            },
                        success: function (responses) {

                        },
                                }); 
                 

                        });
        
        
    </script>
    
</body>

</html>