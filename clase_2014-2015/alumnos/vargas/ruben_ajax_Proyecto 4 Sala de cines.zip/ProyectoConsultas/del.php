<?php

include("conexion.php"); 

		$codigo = $_POST['codigo'];


mysqli_query($conexion,"DELETE FROM `Peliculas` WHERE `cod_peliculas` = ".$codigo.";");



        
        $sql1 = "SELECT  * from Peliculas";
        $consulta1 = mysqli_query($conexion,$sql1);
        while($pelis = mysqli_fetch_array($consulta1)){ 
            echo utf8_encode( '<H3><span class="label label-primary">'.$pelis[0].' '.$pelis[1].'</span></h3>');

        }
        
        echo '<hr>
        <center>
        <select class="form-control paraeliminar">';

        $sql2 = "SELECT  * from Peliculas";
        $consulta2 = mysqli_query($conexion,$sql2);
        while($pelis2 = mysqli_fetch_array($consulta2)){ 
           echo utf8_encode( '<option>'.$pelis2[0].'</option>');
        }
        
        echo '</select>
                </center>
';
        
mysqli_close();
               
?>