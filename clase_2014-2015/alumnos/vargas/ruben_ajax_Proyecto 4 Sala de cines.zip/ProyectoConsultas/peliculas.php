<!DOCTYPE html>
<html lang="es">
<?php include('conexion.php')?>
<head>
    <meta charset="UTF-8">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <script src="css/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
        <style>body{background-color:#1560BD;}</style>
    <title>Document</title>
</head>
<body>
<?php include('menu.php')?>
 <center>
 <div class="list-group" style="width:50%;">
  <a href="#" class="list-group-item active" style="background:#D9534F">
    Cartelera
  </a>
  
  <?php
        $sql = "SELECT  * from Peliculas";
        $consulta = mysqli_query($conexion,$sql);
        while($pelis = mysqli_fetch_array($consulta)){ 
            echo utf8_encode( '<a href="'.$pelis[6].'" class="list-group-item">'.$pelis[1].'</a>');
    
                $sql2 = "SELECT * from sesiones where cod_peliculas='$pelis[0]'";
                $consulta2 = mysqli_query($conexion,$sql2);
                while($sesiones = mysqli_fetch_array($consulta2)){ 
                    echo utf8_encode( '<a href="'.$pelis[6].'" class="list-group-item">Sala: '.$sesiones[0].", Horario: ".$sesiones[2].'.</a>');
                }
            echo utf8_encode( '<a href="'.$pelis[6].'" class="list-group-item">Descripcion: '.$pelis[2].'</a>'); 
    }
        
?>
</div>
</center>
</body>
</html>