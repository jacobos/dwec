<?php

include("conexion.php"); 

		$modifi = $_POST['modifi'];
        
 if(isset($_POST['modifi'])){
     
        $sqla = "SELECT * FROM `Peliculas` WHERE cod_peliculas='".$modifi."'";
        $consultaa = mysqli_query($conexion,$sqla);
        while($pelis = mysqli_fetch_array($consultaa)){ 
           
            echo utf8_encode( '<H3><span class="label label-primary">Codigo </span>'.$pelis[0].' <span class="label label-primary">Titulo </span> '.$pelis[1].' <span class="label label-primary">Descripcion </span> '.$pelis[2].' <span class="label label-primary">Duracion </span> '.$pelis[3].' <span class="label label-primary">Precio </span> '.$pelis[4].'</h3>');

        }
     
    }

/*                    
                           echo'<select class="form-control modifi2">
                               <option> </option>';
                                $sql = "SELECT  * from Peliculas";
                                $consulta = mysqli_query($conexion,$sql);
                                while($horas = mysqli_fetch_array($consulta)){
                                    
                                   echo utf8_encode( '<option>'.$horas[0].'</option>');
                                }
                                
                            echo'</select>
                        </div>';*/

mysqli_close();
?><!--
           		$titulo = $_POST['titulom'];
		$descripcion = $_POST['descripcionm'];
		$duracion = $_POST['duracionm'];
		$precio = $_POST['preciom'];
           
        $sql = "UPDATE Peliculas SET nom_peliculas='".$titulo."', descripcion='".$descripcion."', duracion='".$duracion."', precio='".$precio."' WHERE cod_peliculas ='".$modifi."'";
        $consulta = mysqli_query($conexion,$sql);-->