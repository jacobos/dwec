    <nav class="navbar navbar-default navbar-static-top" style="background-color:#12426B">
        <div class="container">
           <ul class="nav nav-pills nav-justified">
            <li><img src="img/logo.png" style="margin-top:15px; margin-bottom:15px;"></li>
            <li><a href="index.php" class="btn btn-danger btn-lg" style="margin:5px;">inicio</a></li>
            <li><a href="peliculas.php" class="btn btn-danger btn-lg" style="margin:5px;">Peliculas</a></li>
            <li><a href="acceso.php" class="btn btn-danger btn-lg" style="margin:5px;">Acceso Privado</a></li>
            </ul>
        </div>
          </div>
    </nav>