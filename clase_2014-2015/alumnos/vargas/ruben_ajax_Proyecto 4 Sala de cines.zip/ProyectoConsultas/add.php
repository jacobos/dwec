<?php

include("conexion.php"); 

		$codigo = $_POST['codigo'];
		$titulo = $_POST['titulo'];
		$descripcion = $_POST['descripcion'];
		$duracion = $_POST['duracion'];
		$precio = $_POST['precio'];
		$sesion = $_POST['sesion'];
		$sala = $_POST['sala'];
		$horas = $_POST['horas'];
        
if(isset($_POST['titulo'])){
mysqli_query($conexion,"INSERT INTO `Peliculas`(`cod_peliculas`, `nom_peliculas`, `descripcion` ,`duracion`,`precio`) VALUES ('$codigo','$titulo','$descripcion','$duracion','$precio')");
    
    mysqli_query($conexion,"INSERT INTO `sesiones`(`cod_salas`, `cod_peliculas`,`hora`) VALUES ('$sala','$codigo','$horas')");
}

echo '<tr><td>Codigo</td><td>Titulo</td><td>Decripcion</td><td>Duracion</td><td>Precio</td></tr>';
       
        $sqla = "SELECT  * from Peliculas";
        $consultaa = mysqli_query($conexion,$sqla);
        while($pelis = mysqli_fetch_array($consultaa)){ 
           
            echo utf8_encode( '<tr class="fila"><td>'.$pelis[0].'</td><td>'.$pelis[1].'</td><td>'.$pelis[2].'</td><td>'.$pelis[3].'</td><td>'.$pelis[4].'</td><td></tr>');
      
        
        }
mysqli_close();
?>