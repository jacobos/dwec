-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost:3306
-- Tiempo de generación: 06-02-2015 a las 18:07:54
-- Versión del servidor: 5.5.40
-- Versión de PHP: 5.5.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `ProyectoConsultas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Horas`
--

CREATE TABLE IF NOT EXISTS `Horas` (
  `hora` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Horas`
--

INSERT INTO `Horas` (`hora`) VALUES
('10:00'),
('11:30'),
('13:00'),
('14:30'),
('16:00'),
('17:30'),
('19:00'),
('20:30'),
('22:00'),
('23:00'),
('23:30'),
('24:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Peliculas`
--

CREATE TABLE IF NOT EXISTS `Peliculas` (
  `cod_peliculas` int(4) NOT NULL,
  `nom_peliculas` varchar(50) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `duracion` varchar(10) NOT NULL,
  `precio` float NOT NULL,
  `portada` varchar(500) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Peliculas`
--

INSERT INTO `Peliculas` (`cod_peliculas`, `nom_peliculas`, `descripcion`, `duracion`, `precio`, `portada`, `url`) VALUES
(1, 'Proyecto de PHP', 'Es un proyecto de php realizado por ruben ', '3:00 horas', 200, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Salas`
--

CREATE TABLE IF NOT EXISTS `Salas` (
  `cod_salas` int(4) NOT NULL,
  `aforo` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Salas`
--

INSERT INTO `Salas` (`cod_salas`, `aforo`) VALUES
(1, 300),
(2, 500),
(3, 300),
(4, 150);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE IF NOT EXISTS `sesiones` (
  `cod_salas` int(4) NOT NULL,
  `cod_peliculas` int(4) NOT NULL,
  `hora` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sesiones`
--

INSERT INTO `sesiones` (`cod_salas`, `cod_peliculas`, `hora`) VALUES
(3, 1, '20:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `usuario` varchar(30) NOT NULL,
  `contra` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario`, `contra`) VALUES
('admin', '123456');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Horas`
--
ALTER TABLE `Horas`
 ADD PRIMARY KEY (`hora`);

--
-- Indices de la tabla `Peliculas`
--
ALTER TABLE `Peliculas`
 ADD PRIMARY KEY (`cod_peliculas`);

--
-- Indices de la tabla `Salas`
--
ALTER TABLE `Salas`
 ADD PRIMARY KEY (`cod_salas`);

--
-- Indices de la tabla `sesiones`
--
ALTER TABLE `sesiones`
 ADD PRIMARY KEY (`cod_salas`,`cod_peliculas`,`hora`), ADD KEY `cod_peliculas` (`cod_peliculas`), ADD KEY `cod_salas` (`cod_salas`), ADD KEY `hora` (`hora`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `sesiones`
--
ALTER TABLE `sesiones`
ADD CONSTRAINT `sesiones_ibfk_3` FOREIGN KEY (`hora`) REFERENCES `Horas` (`hora`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`cod_peliculas`) REFERENCES `Peliculas` (`cod_peliculas`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `sesiones_ibfk_2` FOREIGN KEY (`cod_salas`) REFERENCES `Salas` (`cod_salas`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
