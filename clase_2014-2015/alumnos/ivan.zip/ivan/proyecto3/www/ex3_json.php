<?php
    header("content-type: application/json");

	$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');


	//the usuario table should exist in your database
	$result = mysqli_query($con,"SELECT * FROM book");
    $i = 0;
	while($row = mysqli_fetch_array($result))
	{
		if($i < 33)
        {
            //we use utf8_encode for special characters in the database (avoid errors with JSON data)
            $array['where'] = utf8_encode($row['editorial']);
            $array['what'] = $row['nombre'];
            $array['desc'] = utf8_encode($row['autor']);
            $array['com'] = utf8_encode($row['Comentario']);
            $num = $i % 4+1;
            $array['img'] =
            "http://ivantortosa.tk/libros/libro".$row['id'].".jpg";
            $i++;
            $back[] = $array;
        }
	}

    echo $_GET['callback']. '('. json_encode($back) . ')';

?>
