module.controller('LandController', ['$scope', '$http',
    function ($scope, $http) {
        $scope.capitales = [{
            img: "http://ivantortosa.tk/libros/libro.jpg",
            what: "Actualiza",
            where: "y veras",
            desc: "tus libros"
        }];
        
                    $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex7_json.php?&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                 console.log("got info from the server!");
                doSomething(data);
                $scope.capitales = data;
                $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
                $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            });

        var doSomething = function (d) {
            console.log("doing Something");

            $scope.capitales.push(d);
            //$scope.$apply();
        }

        $scope.new = function (parametro, parametro2, parametro3) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex2_json.php?info='+parametro+'&info2='+parametro2+'&info3='+parametro3+'&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);
                // data contains the response
                // status is the HTTP status
                // headers is the header getter function
                // config is the object that was used to create the HTTP request
         $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
          $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
        };
      

        $scope.del = function (parametro) {
            
            
        };
        
                $scope.del = function (parametro) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex6_json.php?info='+parametro+'&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log(data);
                console.log("got info from the server!");
                //doSomething(data);
                // data contains the response
                // status is the HTTP status
                // headers is the header getter function
                // config is the object that was used to create the HTTP request
         $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
          $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
        };
        
        
            $scope.act = function () {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex7_json.php?&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                 console.log("got info from the server!");
                doSomething(data);
                $scope.capitales = data;
                $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
                $("#text1").val("");
           $("#text2").val("");
            $("#text3").val("");
            });
                
        };
        
        
        
        
}]);
