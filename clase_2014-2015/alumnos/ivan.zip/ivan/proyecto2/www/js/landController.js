module.controller('LandController', ['$scope', '$http',
    function ($scope, $http) {
        $scope.capitales = [{
            img: "http://ivantortosa.tk/libros/libro.jpg",
            what: "Actualizando",
            where: "puede tardar",
            desc: "unos minutos",
            com: "...."
        }];
        $http({
            method: 'JSONP',
            url: 'http://tortosavalencia.tk/json/ex7_json.php?&callback=JSON_CALLBACK'
        }).success(function (data, status, headers, config) {
            console.log("got info from the server!");
            doSomething(data);
            $scope.capitales = data;
            $("#text1").val("");
            $("#text2").val("");
            $("#text3").val("");
            $("#text4").val("");
        }).error(function (data, status, headers, config) {
            console.log("Some error ocurred");
            $("#text1").val("");
            $("#text2").val("");
            $("#text3").val("");
            $("#text4").val("");
        });
        var doSomething = function (d) {
            console.log("doing Something");


            $scope.capitales.push(d);
            //$scope.$apply();
        }

        $scope.new = function (parametro, parametro2, parametro3, parametro4) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex2_json.php?info=' + parametro + '&info2=' + parametro2 + '&info3=' + parametro3 + '&info4=' + parametro4 + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);
                // data contains the response
                // status is the HTTP status
                // headers is the header getter function
                // config is the object that was used to create the HTTP request
                $("#text1").val("");
                $("#text2").val("");
                $("#text3").val("");
                $("#text4").val("");
                $http({
                    method: 'JSONP',
                    url: 'http://tortosavalencia.tk/json/ex7_json.php?&callback=JSON_CALLBACK'
                }).success(function (data, status, headers, config) {
                    console.log("got info from the server!");
                    doSomething(data);
                    $scope.capitales = data;
                    $("#text1").val("");
                    $("#text2").val("");
                    $("#text3").val("");
                    $("#text4").val("");
                }).error(function (data, status, headers, config) {
                    console.log("Some error ocurred");
                    $("#text1").val("");
                    $("#text2").val("");
                    $("#text3").val("");
                    $("#text4").val("");
                });
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
            $("#text1").val("");
            $("#text2").val("");
            $("#text3").val("");
            $("#text4").val("");
        };

        $scope.del = function (parametro) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex6_json.php?info=' + parametro + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log(data);
                console.log("got info from the server!");
                //doSomething(data);
                // data contains the response
                // status is the HTTP status
                // headers is the header getter function
                // config is the object that was used to create the HTTP request
                $("#text1").val("");
                $("#text2").val("");
                $("#text3").val("");
                $("#text4").val("");
                $http({
                    method: 'JSONP',
                    url: 'http://tortosavalencia.tk/json/ex7_json.php?&callback=JSON_CALLBACK'
                }).success(function (data, status, headers, config) {
                    console.log("got info from the server!");
                    doSomething(data);
                    $scope.capitales = data;
                    $("#text1").val("");
                    $("#text2").val("");
                    $("#text3").val("");
                    $("#text4").val("");
                }).error(function (data, status, headers, config) {
                    console.log("Some error ocurred");
                    $("#text1").val("");
                    $("#text2").val("");
                    $("#text3").val("");
                    $("#text4").val("");
                });
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
            $("#text1").val("");
            $("#text2").val("");
            $("#text3").val("");
            $("#text4").val("");
        };


        $scope.nuevo = function (parametro, parametro2, parametro3, parametro4) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex9_json.php?info=' + parametro + '&info2=' + parametro2 + '&info3=' + parametro3 + '&info4=' + parametro4 + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);
                // data contains the response
                // status is the HTTP status
                // headers is the header getter function
                // config is the object that was used to create the HTTP request
                $("#text1").val("");
                $("#text2").val("");
                $("#text3").val("");
                $("#text4").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
            $("#text1").val("");
            $("#text2").val("");
            $("#text3").val("");
            $("#text4").val("");
        };


        $scope.bus = function (parametro) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex10_json.php?info=' + parametro + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log(data);
                console.log("got info from the server!");
                $("#text1").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            $("#text1").val("");

        };

}]);