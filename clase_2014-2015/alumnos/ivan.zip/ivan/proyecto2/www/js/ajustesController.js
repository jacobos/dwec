 module.controller('ajustesController', ['$scope', '$http',
    function ($scope, $http) {
$scope.user = [{
	        nom: "user1",
            img: "http://ivantortosa.tk/libros/user.png"
            
        }];

        var doSomething = function (d) {
            console.log("doing Something");

            $scope.usuarios.push(d);
        }
        
  $scope.act = function (parametro) {
           $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex5_json.php?info='+parametro+'&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);

            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            }); 
        };
        
         $scope.ver = function () {
           $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex8_json.php?&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);
                $scope.user = data;

            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            }); 
        };
}]);
