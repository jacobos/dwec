module.controller('busController', ['$scope', '$http',
    function ($scope, $http) {

        var doSomething = function (d) {
            console.log("doing Something");


            $scope.capitales.push(d);
            //$scope.$apply();
        }


        $scope.bus = function (parametro) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex10_json.php?info=' + parametro + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                $scope.capitales = data;
                console.log(data);
                console.log("got info from the server!");
                $("#text1").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            $("#text1").val("");

        };


        $scope.new = function (parametro, parametro2, parametro3, parametro4) {
            $http({
                method: 'JSONP',
                url: 'http://tortosavalencia.tk/json/ex11_json.php?info=' + parametro + '&info2=' + parametro2 + '&info3=' + parametro3 + '&info4=' + parametro4 + '&callback=JSON_CALLBACK'
            }).success(function (data, status, headers, config) {
                console.log("got info from the server!");
                doSomething(data);
                $("#text1").val("");
            }).error(function (data, status, headers, config) {
                console.log("Some error ocurred");
            });
            //catitales.push($("#text1").val());
            $("#text1").val("");
        };
}]);