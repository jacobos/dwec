module.controller('PageController', function ($scope) {
    //ons.ready(function() {
    // Init code here
    //  });
});