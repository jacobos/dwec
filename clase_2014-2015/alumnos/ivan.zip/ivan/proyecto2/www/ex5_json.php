<?php
  header("content-type: application/json");
$al = $_GET["info"];

	$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');


	//the usuario table should exist in your database
	mysqli_query($con,"Update user Set nombre='".$al."' Where id='1'");

    echo $_GET['callback']. '('. json_encode("perfecto") . ')';

?>
