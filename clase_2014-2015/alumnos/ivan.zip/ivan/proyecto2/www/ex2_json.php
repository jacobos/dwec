<?php
header("content-type: application/json");

$al = $_GET["info"];
$al2 = $_GET["info2"];
$al3 = $_GET["info3"];
$array['arr'] = array(1,7,4,2,8,4,1,9,3,2,16,7,12);
$array['where'] = $al3;
$array['what'] = $al;
$array['desc'] = $al2;
$array['img'] ="http://ivantortosa.tk/libros/libro.jpg";
$array['canPurchase'] = false;

//echo json_enconde($array);


	$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');

	//the usuario table should exist in your database
mysqli_query($con, "INSERT INTO yourbook (nombre, editorial, autor) VALUES ('".$al."','".$al2."','".$al3."')");

echo $_GET['callback']. '('. json_encode($array) . ')';
	
?>
