<?php

copy($_FILES['foto']['tmp_name'],$_FILES['foto']['name']);
$nom=.$_FILES['foto']['tmp_name'];
echo "<img src=\"$nom\">";
$add="http://ivantortosa.tk/libros/$nom";


$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');
mysqli_query($con,"Update user Set img='".$add."' Where id=1");
?>
