<?php
    header("content-type: application/json");

	$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');


	$result = mysqli_query($con,"SELECT * FROM user");
	while($row = mysqli_fetch_array($result))
	{

            $array['nom'] =$row['nombre'];
            $array['img'] =$row['img'];
            
            $back[] = $array;
	}
    
    echo $_GET['callback']. '('. json_encode($back) . ')';

?>
