<?php
header("content-type: application/json");

$al = $_GET["info"];
$al2 = $_GET["info2"];
$al3 = $_GET["info3"];
$al4 = $_GET["info4"];

//echo json_enconde($array);


	$con=mysqli_connect("localhost","tortosavalencia","tortosa93","world") or die('{"devuelve": "Error en conexion a la DB"}');

	//the usuario table should exist in your database

mysqli_query($con, "INSERT INTO book (nombre, editorial, autor, Comentario) VALUES ('".$al."','".$al2."','".$al3."','".$al4."')");

	
?>
