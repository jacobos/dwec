//var module = angular.module('Onsen', []);
var module = ons.bootstrap('myapo', ['onsen']);
//ons.disableAutoStatusBarFill(); // (Monaca enables StatusBar plugin by default) 649042364
