module.controller('MorningCtrl', function ($scope) {
    $scope.greeting = "Good Morning!";
});
