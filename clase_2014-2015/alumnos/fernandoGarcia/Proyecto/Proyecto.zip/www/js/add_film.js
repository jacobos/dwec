module.controller('added_film', ['$scope', '$http',
 function ($scope, $http) {

$scope.new = function () {
	console.log("Cargando datos en AJAX y BBDD...")
    	  $http({
              method: 'JSONP',
              type: "POST",
              url: 'http://www.fernando-garcia.es/JAVA/Onsen-Monaca/add_json.php?callback=JSON_CALLBACK',
              data: {
  	        	variable1: $('#nombre').val(),
  	            variable2: $('#director').val(),
  	            variable3: $('#ano').val(),
  	            variable4: $('#genero').val(),
  	            variable5: $('#url').val()
  	        }
          }).success(function (data, status, headers, config) {
             // $scope.items = data;
          	console.log("Added film !!");
          }).error(function (data, status, headers, config) {
              console.log("Some error ocurred !");
          });
     };


 }]);

module.controller('favs_films', function ($scope, $http, currentInfoFactory) {
	$scope.itemsPerPage = 5;
    $scope.currentPage = 0;
    $scope.items = [];

    $http({
        method: 'JSONP',
        url: 'http://www.fernando-garcia.es/JAVA/Onsen-Monaca/favs_json.php?callback=JSON_CALLBACK'
    }).success(function (data, status, headers, config) {
        $scope.items = data;
    	console.log(data);
    }).error(function (data, status, headers, config) {
        console.log("Some error ocurred");
    });

    $scope.getCurrentPage = function () {
        return $scope.items.slice($scope.currentPage * $scope.itemsPerPage,
            $scope.currentPage * $scope.itemsPerPage + $scope.itemsPerPage);
    };

    $scope.nextPage = function () {
        //Almost the same as $scope.currentPage++;
        //(simplemente controla que si no hay más paginas a la derecha no aumente)
        $scope.currentPage = Math.min(parseInt(($scope.items.length - 1) / $scope.itemsPerPage),
            $scope.currentPage + 1);
    }

    $scope.prevPage = function () {
        //Almost the same as $scope.currentPage--;
        $scope.currentPage = Math.max(0, $scope.currentPage - 1);
    }
    $scope.ponerSeleccion = function (p) {
        currentInfoFactory.set(p);
    }
   
});
  
