module.controller('DayCtrl', function ($scope) {
    $scope.greeting = "Good day!";
});
