module.controller('NightCtrl', function ($scope) {
    $scope.greeting = "Good Night!";
});
