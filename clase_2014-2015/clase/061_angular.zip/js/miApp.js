(function () {
  var app = angular.module('store', []);
  app.controller('GemitaController', function () {
    this.products = gems;
  });
  var gems = [{
      name: 'Dodecahedron',
      price: 7,
      description: 'Dodecahedron is a nice piece of gem to work with!!',
      canPurchase: true,
      images: [
        {
          full: "im/gem-01.gif",
          small: "im/gem-01.gif"
        }, {
          full: "im/gem-02.gif",
          small: "im/gem-01.gif"
        }, {
          full: "im/gem-03.gif",
          small: "im/gem-01.gif"
        }
      ]
    },
    {
      name: 'Hex',
      price: 4.95,
      description: 'Triangle is nice!!',
      canPurchase: true},
    {
      name: 'TriangleHex',
      price: 3.95,
      description: 'Triangle is nice!!',
      canPurchase: true,
      images: [
        {
          full: "im/gem-03.gif",
          small: "im/gem-03.gif",
            }]
        },
    {
      name: 'Tri Tri',
      price: 4.95,
      description: 'Triangle is nice!!',
      canPurchase: true,
      images: [
        {
          full: "im/gem-04.gif",
          small: "im/gem-04.gif",
            }]
        },
    {
      name: 'Cube',
      price: 9.95,
      description: 'Triangle is nice!!',
      canPurchase: true,
      images: [
        {
          full: "im/gem-05.gif",
          small: "im/gem-05.gif",
            }]
        },
    {
      name: 'Star',
      price: 9.95,
      description: 'Triangle is nice!!',
      canPurchase: true,
      images: [
        {
          full: "im/gem-05.gif",
          small: "im/gem-05.gif",
            }]
        }
               ];
})();