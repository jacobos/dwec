(function() {

  $(document.body).on("click", function() {
    console.log("HI2");
   console.log("NI");
      var y = { x: 1, y: 2 };
      alert("H23365I");
  });
})();
