(function() {

  $(document.body).on("click", function() {
    console.log("HI 33");
  });
})();
