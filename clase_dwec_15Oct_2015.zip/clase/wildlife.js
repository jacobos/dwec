var animals = {
  "antelope": [
      "antelope10.jpg",
      "antelope1.jpg",
      "antelope2.jpg",
      "antelope3.jpg",
      "antelope4.jpg",
      "antelope5.jpg",
      "antelope6.jpg",
      "antelope7.jpg",
      "antelope8.jpg",
      "antelope9.jpg"
   ],
  "axolotl": [
      "axolotl1.jpg",
      "axolotl2.jpg",
      "axolotl3.jpg",
      "axolotl4.jpg",
      "axolotl5.jpg",
      "axolotl6.jpg",
      "axolotl7.jpg"
   ],
  "brown_bear": [
      "brown_bear10.jpg",
      "brown_bear11.jpg",
      "brown_bear12.jpg",
      "brown_bear1.jpg",
      "brown_bear2.jpg",
      "brown_bear3.jpg",
      "brown_bear4.jpg",
      "brown_bear7.jpg",
      "brown_bear8.jpg",
      "brown_bear9.jpg"
   ],
  "budgerigar": [
      "budgerigar11.jpg",
      "budgerigar12.jpg",
      "budgerigar1.jpg",
      "budgerigar2.jpg",
      "budgerigar3.jpg",
      "budgerigar4.jpg",
      "budgerigar5.jpg",
      "budgerigar9.jpg"
   ],
  "buffalo": [
      "buffalo1.jpg",
      "buffalo2.jpg",
      "buffalo4.jpg",
      "buffalo5.jpg",
      "buffalo6.jpg",
      "buffalo7.jpg"
   ],
  "bumble_bee": [
      "bumble_bee1.jpg",
      "bumble_bee2.jpg",
      "bumble_bee3.jpg",
      "bumble_bee4.jpg",
      "bumble_bee5.jpg",
      "bumble_bee6.jpg",
      "bumble_bee7.jpg",
      "bumble_bee8.jpg",
      "bumble_bee9.jpg"
   ],
  "burrowing_frog": [
      "burrowing_frog1.jpg",
      "burrowing_frog2.jpg",
      "burrowing_frog3.jpg"
   ],
  "chameleon": [
      "chameleon2.jpg",
      "chameleon3.jpg",
      "chameleon5.jpg",
      "chameleon7.jpg",
      "chameleon8.jpg"
   ],
  "chicken": [
      "chicken1.jpg",
      "chicken2.jpg",
      "chicken3.jpg",
      "chicken4.jpg",
      "chicken5.jpg",
      "chicken6.jpg",
      "chicken7.jpg",
      "chicken8.jpg",
      "chicken9.jpg"
   ],
  "chimpanzee": [
      "chimpanzee1.jpg",
      "chimpanzee2.jpg",
      "chimpanzee3.jpg",
      "chimpanzee4.jpg",
      "chimpanzee5.jpg",
      "chimpanzee6.jpg",
      "chimpanzee7.jpg",
      "chimpanzee8.jpg"
   ],
  "chinstrap_pengui": [
      "chinstrap_penguin1.jpg",
      "chinstrap_penguin2.jpg",
      "chinstrap_penguin3.jpg",
      "chinstrap_penguin4.jpg",
      "chinstrap_penguin5.jpg",
      "chinstrap_penguin6.jpg"
   ],
  "coati": [
      "coati1.jpg",
      "coati2.jpg",
      "coati3.jpg",
      "coati4.jpg",
      "coati5.jpg",
      "coati6.jpg",
      "coati7.jpg",
      "coati8.jpg"
   ],
  "coral": [
      "coral10.jpg",
      "coral1.jpg",
      "coral2.jpg",
      "coral3.jpg",
      "coral4.jpg",
      "coral5.jpg"
   ],
  "cougar": [
      "cougar2.jpg",
      "cougar4.jpg",
      "cougar5.jpg",
      "cougar6.jpg"
   ],
  "cow": [
      "cow11.jpg",
      "cow1.jpg",
      "cow3.jpg",
      "cow6.jpg"
   ],
  "coyote": [
      "coyote1.jpg",
      "coyote2.jpg",
      "coyote3.jpg",
      "coyote4.jpg",
      "coyote5.jpg",
      "coyote6.jpg"
   ],
  "crab": [
      "crab1.jpg",
      "crab2.jpg",
      "crab3.jpg",
      "crab4.jpg",
      "crab5.jpg",
      "crab6.jpg",
      "crab7.jpg",
      "crab8.jpg"
   ],
  "crab-eating-macaque": [
      "crab-eating_macaque1.jpg",
      "crab-eating_macaque2.jpg",
      "crab-eating_macaque3.jpg",
      "crab-eating_macaque4.jpg",
      "crab-eating_macaque5.jpg"
   ],
  "crane": [
      "crane1.jpg",
      "crane2.jpg",
      "crane4.jpg",
      "crane5.jpg"
   ],
  "cuscus": [
      "cuscus1.jpg",
      "cuscus2.jpg",
      "cuscus3.jpg",
      "cuscus4.jpg",
      "cuscus5.jpg",
      "cuscus6.jpg"
   ],
  "cuttlefish": [
      "cuttlefish1.jpg",
      "cuttlefish2.jpg",
      "cuttlefish3.jpg",
      "cuttlefish4.jpg",
      "cuttlefish5.jpg",
      "cuttlefish6.jpg",
      "cuttlefish7.jpg",
      "cuttlefish8.jpg"
   ]
};