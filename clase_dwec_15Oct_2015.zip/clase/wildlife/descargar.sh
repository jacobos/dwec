#!/bin/bash

for (( c = 1; c <= 15; c++ ))
do
	wget http://a-z-animals.com/media/animals/images/470x370/axolotl"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/brown_bear"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/budgerigar"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/buffalo"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/bumble_bee"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/burrowing_frog"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/cuttlefish"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/cuscus"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/crane"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/crab-eating_macaque"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/crab"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/coyote"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/cow"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/cougar"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/coral"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/chimpanzee"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/chicken"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/chameleon"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/coati"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/chinstrap_penguin"$c".jpg
	wget http://a-z-animals.com/media/animals/images/470x370/antelope"$c".jpg
done
