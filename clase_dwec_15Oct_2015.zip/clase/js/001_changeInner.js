function myFunction() {
  var pe = document.getElementById("demo");
  pe.innerHTML = "P inner html changed to this <br> :)";
}